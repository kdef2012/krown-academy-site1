import Link from "next/link";

function Pillar({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="border-2 border-krown-light hover:border-krown-red p-8 transition-all duration-300 group relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-1 bg-krown-red scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="font-display text-lg font-semibold tracking-wider uppercase mb-3">{title}</h3>
      <p className="text-krown-gray leading-relaxed text-[15px]">{desc}</p>
    </div>
  );
}

function StatBox({ number, label }: { number: string; label: string }) {
  return (
    <div className="bg-white p-6 text-center border-l-4 border-krown-red">
      <div className="font-display text-4xl font-bold text-krown-red">{number}</div>
      <div className="text-xs text-krown-gray uppercase tracking-wider mt-1">{label}</div>
    </div>
  );
}

export default function Home() {
  return (
    <>
      {/* ===== HERO ===== */}
      <section className="bg-krown-black text-white text-center py-20 md:py-28 relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 40px, #CC0000 40px, #CC0000 80px)"
        }} />
        <div className="relative z-10 max-w-4xl mx-auto px-4">
          <img src="/logo-web.png" alt="Krown Academy" className="w-40 h-40 mx-auto mb-6" />
          <h1 className="font-display text-5xl sm:text-6xl md:text-8xl font-bold text-krown-red tracking-wider leading-none">
            KROWN ACADEMY
          </h1>
          <p className="font-display text-xl md:text-2xl font-semibold tracking-[0.5em] uppercase mt-2 mb-6">
            Kings &amp; Queens
          </p>
          <div className="w-20 h-1 bg-krown-red mx-auto mb-6" />
          <p className="text-xl md:text-2xl italic text-krown-red font-light mb-6">
            &ldquo;Earn Your Krown&rdquo;
          </p>
          <p className="text-white/70 text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
            A private school for at-risk youth and student-athletes. I develop
            the whole King and Queen — mind, body, and character — through
            rigorous academics and championship-level wrestling.
          </p>
          <Link
            href="/enrollment"
            className="inline-block bg-krown-red hover:bg-krown-dark-red text-white font-display text-base font-semibold tracking-[0.3em] uppercase px-10 py-4 transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-krown-red/30"
          >
            ENROLL YOUR KING OR QUEEN
          </Link>
        </div>
      </section>

      {/* ===== QUOTE BAR ===== */}
      <div className="bg-krown-red text-white text-center py-6 px-4">
        <p className="font-display text-base md:text-lg font-semibold tracking-wider">
          &ldquo;BRING ME METAL, I&apos;LL MAKE YOU A HAMMER.&rdquo; — COACH KENDALL NELSON, FOUNDER
        </p>
      </div>

      {/* ===== TWO PILLARS ===== */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center tracking-wider mb-3">
            TWO PILLARS. ONE STANDARD.
          </h2>
          <p className="text-center text-krown-gray max-w-2xl mx-auto mb-14 leading-relaxed">
            Krown Academy stands on two pillars — each prestigious, each held to
            the highest standard. My Kings &amp; Queens are scholars AND athletes.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Pillar
              icon="📚"
              title="Academic Excellence"
              desc="A college-preparatory academic environment with small class sizes, AI-powered personalized assessment, and NC standards-aligned curriculum. My scholars leave ready to compete in any academic arena."
            />
            <Pillar
              icon="🤼"
              title="Wrestling Program"
              desc="Championship-level coaching from Coach Kendall Nelson, co-owner of K-Vegas Elite Wrestling Club. The foundation of Krown Academy athletics. Kings & Queens who prefer not to wrestle join our structured PE program."
            />
            <Pillar
              icon="♚"
              title="Character Development"
              desc="The pessimist complains about the wind. The optimist expects it to change. At Krown Academy, we adjust the sails. I build realists who take action."
            />
            <Pillar
              icon="🏆"
              title="Competitive Pathway"
              desc="USA Wrestling Preseason Nationals. NCISAA State Championships. A pipeline to collegiate athletics. My Kings & Queens don't just train — they compete at the highest levels."
            />
          </div>
        </div>
      </section>

      {/* ===== STATS BAR ===== */}
      <section className="bg-krown-light py-16 px-4">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          <StatBox number="6–12" label="Grades Served" />
          <StatBox number="15:1" label="Student-Teacher Ratio" />
          <StatBox number="$0" label="Tuition for Qualifying Families" />
          <StatBox number="90 min" label="Daily Wrestling / PE" />
        </div>
      </section>

      {/* ===== DAILY SCHEDULE PREVIEW ===== */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-display text-3xl font-bold text-center tracking-wider mb-3">
            A DAY AT KROWN ACADEMY
          </h2>
          <p className="text-center text-krown-gray mb-12">
            School hours: 8:00 AM – 3:00 PM · Monday through Friday
          </p>
          <div className="grid md:grid-cols-2 gap-10">
            <div>
              <h3 className="font-display text-lg font-semibold text-krown-red tracking-wider uppercase mb-6">
                Academic Blocks
              </h3>
              {[
                ["8:00 – 8:15 AM", "Morning Mindset / Team Huddle"],
                ["8:15 – 9:45 AM", "Academic Block 1: Mathematics"],
                ["10:00 – 11:30 AM", "Academic Block 2: ELA / Science / History"],
                ["2:00 – 2:45 PM", "Tutoring / Enrichment / Exit Tickets"],
              ].map(([time, activity]) => (
                <div
                  key={time}
                  className="flex justify-between py-3 border-b border-krown-light text-[15px]"
                >
                  <span className="font-semibold min-w-[140px]">{time}</span>
                  <span className="text-krown-gray">{activity}</span>
                </div>
              ))}
            </div>
            <div>
              <h3 className="font-display text-lg font-semibold text-krown-red tracking-wider uppercase mb-6">
                Wrestling / PE
              </h3>
              {[
                ["12:15 – 1:45 PM", "Wrestling / PE Block"],
                ["1:45 – 2:00 PM", "Cool Down / Sports Psychology"],
                ["Year 1 Sports", "Wrestling · Functional Fitness"],
                ["Coming Soon", "Basketball · Track & Field · Football"],
              ].map(([time, activity]) => (
                <div
                  key={time}
                  className="flex justify-between py-3 border-b border-krown-light text-[15px]"
                >
                  <span className="font-semibold min-w-[140px]">{time}</span>
                  <span className="text-krown-gray">{activity}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ===== FREE TUITION CTA ===== */}
      <section className="bg-krown-black text-white py-20 px-4 text-center">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-krown-red tracking-wider mb-6">
          TUITION: FREE FOR QUALIFYING FAMILIES
        </h2>
        <p className="font-display text-4xl md:text-5xl font-bold mb-6">
          $7,468/year — <span className="text-krown-red">100% covered</span>
        </p>
        <p className="text-white/70 max-w-xl mx-auto mb-8 leading-relaxed">
          I set Krown Academy&apos;s tuition so that families qualifying for the
          NC Opportunity Scholarship attend at absolutely zero cost. I will
          personally walk every family through the application.
        </p>
        <Link
          href="/scholarships"
          className="inline-block border-2 border-white hover:bg-white hover:text-krown-red text-white font-display text-sm font-semibold tracking-[0.3em] uppercase px-10 py-4 transition-colors"
        >
          LEARN ABOUT FREE TUITION
        </Link>
      </section>
    </>
  );
}
